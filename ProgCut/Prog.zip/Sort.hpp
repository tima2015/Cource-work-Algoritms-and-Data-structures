#ifndef SORT_HPP
#define SORT_HPP

void bubbleSort(int* array, int n);

void quickSort(int* array,int first, int last);

#endif //SORT_HPP